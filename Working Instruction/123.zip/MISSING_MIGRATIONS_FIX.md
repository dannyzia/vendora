# Missing Migrations - Quick Fix Guide

## Problem
Your migrations were failing because 4 migration files were missing from your project:
- ❌ `2025_01_01_000006_create_digital_products_table.php`
- ❌ `2025_01_01_000007_create_service_products_table.php`
- ❌ `2025_01_01_000012_create_disputes_table.php`
- ❌ `2025_01_01_000013_create_reviews_table.php`

These files exist in your **plugin directories** but were not in the main `database/migrations/` folder!

---

## ✅ Solution (1 Minute)

### Step 1: Copy all 4 migration files

```bash
# Copy all 4 files to your migrations directory
cp 2025_01_01_000006_create_digital_products_table.php database/migrations/
cp 2025_01_01_000007_create_service_products_table.php database/migrations/
cp 2025_01_01_000012_create_disputes_table.php database/migrations/
cp 2025_01_01_000013_create_reviews_table.php database/migrations/
```

### Step 2: Run migrations

```bash
php artisan migrate:fresh
```

**That's it!** Your migrations should now run successfully.

---

## What Each File Does

### 1. Digital Products Table (000006)
Creates table for digital product downloads:
- File storage (path, name, type, size)
- License keys
- Download limits and expiry
- Version control

### 2. Service Products Table (000007) ⚠️ CRITICAL
Creates table for service/booking products:
- Duration and availability
- Virtual/in-person locations
- Booking settings
- Cancellation policies

**This is the one that was causing your error!**

### 3. Disputes Table (000012)
Creates table for order disputes:
- Customer complaints
- Vendor responses
- Admin mediation
- Refund tracking

### 4. Reviews Table (000013)
Creates table for product reviews:
- Ratings and comments
- Verification status
- Moderation
- Vendor responses

---

## Migration Order (Fixed!)

Your migrations will now run in this correct order:

```
✅ 000001 - users
✅ 000002 - vendors
✅ 000003 - categories
✅ 000004 - products
✅ 000005 - physical_products
✅ 000006 - digital_products        (NOW PRESENT!)
✅ 000007 - service_products        (NOW PRESENT!)
✅ 000008 - orders
✅ 000009 - order_items
✅ 000010 - payouts
✅ 000011 - commission_ledgers
✅ 000012 - disputes                (NOW PRESENT!)
✅ 000013 - reviews                 (NOW PRESENT!)
✅ 000014 - additional_tables       (NOW WORKS!)
```

---

## Why This Happened

Your project uses a **plugin architecture** where:
- Core tables → `database/migrations/`
- Plugin tables → `plugins/[plugin-name]/database/migrations/`

These 4 tables are **plugin-related** but are **required by core tables**, so they need to be in the main migrations folder.

---

## Verification

After running migrations, verify all tables exist:

```bash
php artisan tinker
```

```php
# Check if all tables exist
Schema::hasTable('digital_products');  // Should return: true
Schema::hasTable('service_products');  // Should return: true
Schema::hasTable('disputes');          // Should return: true
Schema::hasTable('reviews');           // Should return: true
Schema::hasTable('bookings');          // Should return: true
```

---

## Next Steps

After migrations run successfully:

1. ✅ Test vendor registration (from previous fix)
2. ✅ Test vendor onboarding Step 1 (international address)
3. Continue with your marketplace development!

---

## If Still Having Issues

### Error: "Table already exists"
```bash
php artisan migrate:fresh
```

### Error: "doctrine/dbal required"
```bash
composer require doctrine/dbal
```

### Check migration status
```bash
php artisan migrate:status
```

---

## Summary

✅ **Added 4 missing migration files**
✅ **Fixed foreign key dependency error**
✅ **Migrations will now run in correct order**
✅ **All tables will be created successfully**

**Total fix time:** ~1 minute
